import React from "react";

const Rank = () => {
  return (
    <div>
      <p className="f3 white">Your current rank is: </p>
      <p className="f1 white">{"#1"}</p>
    </div>
  );
};

export default Rank;
